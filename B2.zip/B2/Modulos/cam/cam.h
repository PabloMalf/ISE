#ifndef __CAM_H__
#define __CAM_H__

//PLACEHOLDER

#endif
