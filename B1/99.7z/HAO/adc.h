#ifndef __VOL_H
#define __VOL_H

#include "stm32f4xx_hal.h"

#define MY_ADC_VREF 3.3f
#define MY_ADC_RESOLUTION 4096U

void myADC_Init(ADC_HandleTypeDef *hadc);

uint32_t	myADC_Get_Voltage(ADC_HandleTypeDef *hadc);
#endif
