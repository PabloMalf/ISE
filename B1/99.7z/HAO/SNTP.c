#include "SNTP.h"
 
osThreadId_t tid_ThSNTP;  
 
const NET_ADDR4 ntp_server_1 = { NET_ADDR_IP4 , 0, 193, 147, 107,  33 };
const NET_ADDR4 ntp_server_2 = { NET_ADDR_IP4 , 0, 130, 206,   3, 166 };
 
uint8_t sel_SNTP_Server = 0;
 
static void time_callback (uint32_t seconds, uint32_t seconds_fraction);
void STNP_Thread (void *argument);
 
osTimerId_t timer_SNTP;
osStatus_t status;
 
const char* getNetstatusError[] =	{"Operation succeeded"
																	,"Process is busy"
																	,"Unspecified error"
																	,"Invalid parameter specified"
																	,"Wrong state error"
																	,"Driver error"
																	,"Server error"
																	,"User authentication failed"
																	,"DNS host resolver failed"
																	,"File not found or file r/w error"
																	,"Time out"};
 
																	
void get_SNTP_Time(void){
	netStatus code;
	code = netSNTPc_GetTime((NET_ADDR *)(sel_SNTP_Server ? &ntp_server_1 : &ntp_server_2), time_callback);
	if(code == netOK){
		printf ("SNTP request sent to %s .\n", sel_SNTP_Server ? "Instituto IMDEA Software" : "RedIris");
	}
	else{
		printf ("SNTP not ready or bad parameters.\n ERROR: %s \n", getNetstatusError[code]);
	}
}
 
 
static void time_callback (uint32_t seconds, uint32_t seconds_fraction) {
  if (seconds == 0) {
    printf ("Server not responding or bad response.\n");
  }
  else {
    printf ("%d seconds elapsed since 1.1.1970\n", seconds);
    getLocalTime(seconds);
  }
}
 
 
void getLocalTime(uint32_t seconds){ //secs to Local Time
  time_t rawtime = seconds;
  struct tm ts;
  char buf[80];
  ts = *localtime(&rawtime);
  strftime(buf, sizeof(buf), "%a %Y-%m-%d %H:%M:%S %Z", &ts);
	Set_RTC_Time(ts.tm_hour+1, ts.tm_min, ts.tm_sec);				// Hora + 1 porque el que devuelve est� retrasado 1 hora
	Set_RTC_Date(ts.tm_year-100, ts.tm_mon+1, ts.tm_wday, ts.tm_mday);
 
}
 
 
int Init_ThSNTP (void) {
  tid_ThSNTP = osThreadNew(STNP_Thread, NULL, NULL);
  if(tid_ThSNTP == NULL) {
    return(-1);
  }
  return(0);
}
 
 
static void TimerV_Callback(void const *arg){			// Callback creada para el timer virtual
	osDelay(1000);
	get_SNTP_Time();
	osThreadFlagsSet(tid_ThSNTP, 1);
}
 
 
int Init_timer_SNTP (void){
	uint32_t exec = 8U;
	timer_SNTP = osTimerNew((osTimerFunc_t)&TimerV_Callback, osTimerOnce, &exec, NULL);				// Se ha elegido periodic para que se lance cada 3 minutos
	if(timer_SNTP != NULL){
		//status = osTimerStart(timer_id, 1000U);		// Esta parte es solo para verificar que no da errores
		if(status != osOK){
			return -1;
		}
	}
	return NULL;
}
 
 
void STNP_Thread(void *argument) {
	while(1){
		osDelay(1000);
		get_SNTP_Time();
	}
}