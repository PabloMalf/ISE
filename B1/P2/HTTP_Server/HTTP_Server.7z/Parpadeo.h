#ifndef __PARPADEO_H
#define __PARPADEO_H

int Init_Parpadeo (void);

#endif
